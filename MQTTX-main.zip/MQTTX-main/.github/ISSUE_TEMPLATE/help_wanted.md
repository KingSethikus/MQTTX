---
name: Help_Wanted
about: Confuse about the use of MQTTX
title: "[Help] the title of Help_Want report"
labels: help wanted
assignees: ''

---

#### Describe the problem you Confuse

A clear and concise description of what you are confusing about.

#### More detail (optional)

Add any other context or screenshots.
