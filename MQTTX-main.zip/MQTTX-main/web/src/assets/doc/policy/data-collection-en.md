# Data Collection Disclaimer

We prioritize your data privacy and security. Please note the following:

* All configuration data is processed locally on your machine and never leaves your browser.
* Any topic and message data is solely related to the MQTT Broker you are connected to.
* We do not perform any cloud operations or data processing.
* We use Google Tag Manager (GTM) and Google Analytics (GA) only to collect page visit metrics, and no user privacy data is involved.

Thank you for your trust and support.
