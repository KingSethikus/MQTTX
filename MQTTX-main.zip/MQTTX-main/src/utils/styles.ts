export enum LeftValues {
  Show = '341px',
  Hide = '81px',
}

export enum DetailLeftValues {
  Show = '571px',
  Hide = '311px',
}

export enum BodyTopValues {
  Open = '249px',
  Close = '60px',
}

export enum MsgTopValues {
  Open = '282px',
  Close = '91px',
}
