//Log data holdplace
export interface LogModel {
  id?: string
  content: string
  type: string
}
