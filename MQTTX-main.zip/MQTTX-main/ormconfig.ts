const ORMConfig = require('./src/database/database.config')
module.exports = ORMConfig.default
